#!/usr/bin/python2
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from getpass import getpass
from smtplib import SMTP
mail = MIMEMultipart()
mailfrom = raw_input("nsmtp v1.0\n [+] From: ")
mail["From"] = mailfrom
mailto = raw_input(" [+] To: ")
mail["To"] = mailto
mail["Subject"] = raw_input(" [+] Subject: ")
maildata = raw_input(" [+] Data:\n------------------------------------------------\n")
while True:
    try: maildata += ("\n" + raw_input())
    except: break
print("-"*48)
mail.attach(MIMEText(maildata, "plain"))
try: smtpCon = SMTP("smtp.nauta.cu", 25)
except:
    print("nsmtp: can't reach server")
    exit()
try: smtpCon.login(mailfrom, getpass(" [+] Password: "))
except:
    print("nsmtp: invalid credentials")
    exit()
try: smtpCon.sendmail(mailfrom, mailto, mail.as_string())
except:
    print("nsmtp: can't send mail")
    exit()
print("nsmtp: mail sent")
smtpCon.close()