#!/usr/bin/python3
def collatz(n):
	if n % 2 == 0:
		x = n // 2
		print(x)
		return x
	else:
		x = 3 * n + 1
		print(x)
		return x
i = int(input(">>> "))
while True:
	i = collatz(i)
	if i == 1: break
