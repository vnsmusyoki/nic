from sl4a import Android
from time import localtime, sleep
droid = Android()
previousVolume = droid.getMediaVolume().result
droid.setMediaVolume(round(droid.getMaxMediaVolume().result/2))
droid.dialogCreateTimePicker(0, 0, True)
droid.dialogShow()
time = droid.dialogGetResponse().result
hour, minute = time["hour"], time["minute"]
droid.dialogDismiss()
def get_12h_format_hour():
    if hour > 12: return hour-12
    return hour
def fixed_str_of_int(_int, isHour=False):
    _str = str(_int)
    if len(_str) == 1: _str = "0"+_str
    if _str == "00" and isHour: return "12"
    return _str
def am_or_pm():
    if hour >= 12: return "p.m."
    else: return "a.m."
text = fixed_str_of_int(get_12h_format_hour(), True)+":"+fixed_str_of_int(minute)+" "+am_or_pm()
print("Waiting till: "+text)
while True:
    time = localtime()
    if time[3] == hour and time[4] == minute:
        droid.mediaPlay("/sdcard/qpython/projects3/Alarmos/beep.mp3")
        droid.mediaPlaySetLooping()
        input("Press RETURN to dismiss alarm...")
        droid.mediaPlayClose()
        break
    sleep(1)
droid.setMediaVolume(previousVolume)