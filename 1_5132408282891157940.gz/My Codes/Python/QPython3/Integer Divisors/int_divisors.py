# int_divisors.py
# Finds an integer's divisors

try:
    x = int(input("\nx << "))
except:
    print("\nMust provide an integer")
    exit()

if x == 0:
    print("\nInteger can't be zero\nBecause zero has infinite divisors\nExcepting itself; interval: (-∞; 0) U (0; +∞)")
    exit()
    
if str(x).startswith('-'):
    x = int(str(x)[1:])

d = "\n"
y = 1
while y <= x:
    print("\b\b\b\b\b" + ("\b"*len(str(y))) + "y >> " + str(y), end="")
    if (x % y) == 0:
        d = d + "\n±" + str(y) + (" "*((len(str(x)) - len(str(y))))) + " : " + str(x) + "/±" + str(y) + (" "*((len(str(x)) - len(str(y))))) + " = ±" + str(int(x / y))
    y += 1
print(d)