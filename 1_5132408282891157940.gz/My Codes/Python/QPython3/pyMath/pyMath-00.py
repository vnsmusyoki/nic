print("pyMath-00")
def factorial(n):
    f = 1
    while n > 1:
        f *= n
        n -= 1
    return f
while True:
    o = int(input("[1] Cnp\n[2] PN\n[3] Vnp\n[4] Exit\n>>> "))
    if o == 4: exit()
    elif o != 1 and o != 2 and o != 3: print("invalid option")
    else:
        n = int(input("n: "))
        p = int(input("p: "))
        if o == 3:
            if n != p: print("Vnp: "+str(int(factorial(n)/(factorial(n-p)))))
            else: print("Pn: "+str(int(factorial(n))))
        elif o == 1: print("Cnp: "+str(int(factorial(n)/(factorial(p)*(factorial(n-p))))))
        else:
            PN = str(n/p)[:str(n/p).find(".")+3]
            if not str((n/p)*100).endswith(".0"): PNxCent = str((n/p)*100)[:str((n/p)*100).find(".")+3]+"%"
            else: PNxCent = str((n/p)*100)[:str((n/p)*100).find(".")]+"%"
            print("PN: "+PN+", "+PNxCent)