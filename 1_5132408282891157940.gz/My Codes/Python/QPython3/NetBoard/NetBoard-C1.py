from socket import socket
_socket = socket()
host = input("CONNECT TO ")
_socket.connect((host, 2022))
print("\033[1A\033[7CED TO "+host)
while True:
    command = input(host+"/:SendKeys> ")
    if command == "HELP": print("NetBoard-S1 Help:\n- Send keys by sending strings.\n- Send special characters by sending their respective representations.\n\nSpecial Characters:\n- Backspace:   <BS>\n- Caps Lock:   <CAPSLOCK>\n- Delete:      <DEL>\n- Down Arrow:  <DOWN>\n- End:         <END>\n- Enter:       <ENTER>\n- FN Keys:     <F1>, <F...>, <F12>\n- Home:        <HOME>\n- Left Arrow:  <LEFT>\n- Page Down:   <PGDN>\n- Page Up:     <PGUP>\n- Right Arrow: <RIGHT>\n- Tab:         <TAB>\n- Up Arrow:    <UP>")
    else:
        _socket.send(bytes(command.replace(":>", "<ENTER>")+"END OF PACKET", "utf-8"))
        if command == "DISMISS": break
        print("ALL KEYS SENT TO", host)
_socket.close()
print("CONNECTION CLOSED BY FOREIGN HOST")