from os import system
f = open("/sdcard/qpython/scripts3/.refill_cut_the_rope_magic_energy.db", "r")
b = int(f.readline())
f.close()
if b != 1:
    f = open("/sdcard/qpython/scripts3/.refill_cut_the_rope_magic_energy.db", "w")
    f.write("1")
    f.close()
    print("Initializing root...")
    system("/data/data/org.qpython.qpy3/files/bin/qpython-root.sh /sdcard/qpython/scripts3/refill_cut_the_rope_magic_energy.py")
else:
    f = open("/data/data/com.zeptolab.ctrm.free.google/shared_prefs/CTRM.xml", "r+")
    b = 0
    while True:
        line = f.readline()
        if not line: break
        if line.startswith("    <int name=\"SS_SATIETY_ENERGY\""):
            f.seek(b)
            if len(line[41:line.find("\" />")]) == 1: n = "0"
            else: n = "00"
            f.write("    <int name=\"SS_SATIETY_ENERGY\" value=\""+n+"\" />")
            f.close()
            f = open("/sdcard/qpython/scripts3/.refill_cut_the_rope_magic_energy.db", "w")
            f.write("0")
            f.close()
            print("Process completed...")
            exit()
        b += len(line)