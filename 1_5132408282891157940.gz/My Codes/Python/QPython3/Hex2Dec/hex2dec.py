from sl4a import Android
while True:
    i = input("\x1b[32;40m0x").lower()
    n = len(i)-1
    y = 0
    f = 0
    for c in i:
        if not c in "0123456789abcdef":
            print("\x1b[0m\x1b[1A\x1b["+str(len(i)+2)+"C;->\x1b[31;40merror\x1b[0m")
            f = 1
    if f == 0:
        for c in i:
            if c in "abcdef":
                if c == "a": x = 10
                elif c == "b": x = 11
                elif c == "c": x = 12
                elif c == "d": x = 13
                elif c == "e": x = 14
                elif c == "f": x = 15
            else: x = int(c)
            y += x*(pow(16, n))
            n -= 1
        print("\x1b[0m\x1b[1A\x1b["+str(len(i)+2)+"C;->\x1b[32;40m"+str(y)+"\x1b[0m")
        Android().setClipboard(str(y))