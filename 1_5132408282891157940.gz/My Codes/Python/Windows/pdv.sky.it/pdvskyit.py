from csv import writer
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from time import sleep

driver = webdriver.Chrome()
driver.get("https://pdv.sky.it/")
wait = WebDriverWait(driver, 40)

input("Please login and go to search page")
driver.switch_to.window(driver.window_handles[-1])

codes = []
rf = open("datas.txt", "r")
while True:
	code = rf.readline()
	if not code: break
	codes += [code]
rf.close()

for code in codes:
	driver.switch_to.default_content()
	driver.find_element_by_xpath("//span[contains(text(),'Crea Interazione manuale')]/parent::button").click()
	sleep(1)
	driver.switch_to.frame(driver.find_element_by_xpath("//iframe[contains(@src,'/servlet/servlet.')]"))
	driver.find_element_by_xpath("//input[contains(@name,'ButtonRetail')]").click()
	while True:
		try:
			driver.switch_to.alert.accept()
			break
		except: sleep(1)
	driver.switch_to.default_content()
	sleep(5)

	wait.until(EC.visibility_of_element_located((By.XPATH, "//iframe[contains(@name,'ext-comp')][contains(@src,'Account')]")))
	driver.switch_to.frame(driver.find_element_by_xpath("//iframe[contains(@name,'ext-comp')][contains(@src,'Account')]"))
	wait.until(EC.visibility_of_element_located((By.XPATH, "//input[contains(@id,'txtCF')]")))
	driver.find_element_by_xpath("//input[contains(@id,'txtCF')]").clear()
	driver.find_element_by_xpath("//input[contains(@id,'txtCF')]").send_keys(code)
	driver.execute_script("arguments[0].click()",driver.find_element_by_xpath("//input[@value='CERCA']"))
	sleep(1)

	while True:
		try:
			driver.find_element_by_xpath("//input[contains(@value,'Ricerca in cors')]/parent::span[contains(@style,'display: none')]")
			break
		except:
			sleep(1)
			continue

	try: phone = driver.find_element_by_xpath("//div[contains(@id,'searchResults')]//td[4]").get_attribute("innerText")
	except: phone = "-"
	try: sphone = driver.find_element_by_xpath("//div[contains(@id,'searchResults')]//td[5]").get_attribute("innerText")
	except: sphone = "-"

	try: driver.find_element_by_xpath("//div[contains(@id,'searchResults')]//td/a").click()
	except: continue
	sleep(2)

	if driver.page_source.find("L'interazione corrente risulta già ") > -1: continue
	driver.switch_to.default_content()
	sleep(2)

	try:
		wait.until(EC.visibility_of_element_located((By.XPATH, "//iframe[contains(@name,'ext-comp')][contains(@src,'HomeClien')]")))
		driver.switch_to.frame(driver.find_element_by_xpath("//iframe[contains(@name,'ext-comp')][contains(@src,'HomeClien')]"))
		wait.until(EC.visibility_of_element_located((By.XPATH, "//a[contains(@href,'Dettaglio')]")))
		driver.execute_script("arguments[0].click()",driver.find_element_by_xpath("//a[contains(@href,'Dettaglio')]"))
		driver.switch_to.default_content()
		wait.until(EC.visibility_of_element_located((By.XPATH, "//iframe[contains(@src,'Dettaglio')]")))
		driver.switch_to.frame(driver.find_element_by_xpath("//iframe[contains(@src,'Dettaglio')]"))
		wait.until(EC.visibility_of_element_located((By.XPATH, "//th[contains(text(),'Metodo di Pagamento')]/following-sibling::td/span")))

		try: nominativo = driver.find_element_by_xpath("//*[contains(text(),'Nominativo Sottoscrittore')]/following-sibling::td[1]/span").get_attribute("innerText")
		except: nominativo = "-"
		try: metodo = driver.find_element_by_xpath("//th[contains(text(),'Metodo di Pagamento')]/following-sibling::td/span").get_attribute("innerText")
		except: metodo = "-"
		try: nameBank = driver.find_element_by_xpath("//th[contains(text(),'Nome Banca')]/following-sibling::td/span").get_attribute("innerText")
		except: nameBank = "-"
		try: iban = driver.find_element_by_xpath("//*[text()='IBAN']/parent::th/following-sibling::td/span").get_attribute("innerText")
		except: iban = "-"
		try: ABI = driver.find_element_by_xpath("//*[contains(text(),'ABI')]/following-sibling::td[1]/span").get_attribute("innerText")
		except: ABI = "-"
		try: intestatario = driver.find_element_by_xpath("//*[contains(text(),'Intestatario')]/following-sibling::td[1]/span").get_attribute("innerText")
		except: intestatario = "-"
		try: numeroCarta = driver.find_element_by_xpath("//*[contains(text(),'Numero Carta')]/parent::th/following-sibling::td[1]/span").get_attribute("innerText")
		except: numeroCarta = "-"
		try: meseScadenza = driver.find_element_by_xpath("//*[contains(text(),'Mese Scadenza')]/following-sibling::td[1]/span").get_attribute("innerText")
		except: meseScadenza = "-"
		try: annoScadenza = driver.find_element_by_xpath("//*[contains(text(),'Anno Scadenza')]/following-sibling::td[1]/span").get_attribute("innerText")
		except: annoScadenza = "-"

		with open("outfile.csv","a+",newline="") as of:
		    w = writer(of, delimiter=";")
		    w.writerow([code[:-1],nominativo,metodo,nameBank,iban,ABI,intestatario,numeroCarta,meseScadenza,annoScadenza,phone,sphone])
	except: pass

	driver.switch_to.default_content()
	driver.execute_script("arguments[0].click()",driver.find_element_by_xpath("//a[contains(@class,'x-tab-strip-close')]/parent::li/following-sibling::li[contains(@id,'navigatortabadd')]/preceding-sibling::li[1]/a[1]"))

driver.quit()