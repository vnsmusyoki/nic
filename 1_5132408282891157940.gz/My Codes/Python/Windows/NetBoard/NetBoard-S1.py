from os import system
from socket import gethostname, socket
_socket = socket()
host = gethostname()
_socket.bind((host, 2022))
_socket.listen(1)
print("RUNNING ON", host)
while True:
    channel, address = _socket.accept()
    print("GOT CONNECTION FROM", address[0])
    while True:
        command = str()
        while True:
            command += channel.recv(1024).decode()
            if command.endswith("END OF PACKET"): break
        command = command[:-13]
        if command == "DISMISS": break
        else:
            print("GOT KEY FROM", address[0])
            flag = False
            for key in ["<BS>", "<CAPSLOCK>", "<DEL>", "<DOWN>", "<END>", "<ENTER>", "<F1>", "<F2>", "<F3>", "<F4>", "<F5>", "<F6>", "<F7>", "<F8>", "<F9>", "<F10>", "<F11>", "<F12>", "<HOME>", "<LEFT>", "<PGDN>", "<PGUP>", "<RIGHT>", "<TAB>", "<UP>"]:
                if key in command:
                    flag = True
                    break
            if flag: system("SendKeys "+(command.replace("<", "{").replace(">", "}")))
            else:
                for char in command:
                    if char == '"': system("SendKeys DOUBLE_QUOTE")
                    else:
                        if char in "+^%~{}<>&()| ": char = '"{'+char+'}"'
                        system("SendKeys "+char)
    channel.close()
    print("CONNECTION CLOSED TO", address[0])