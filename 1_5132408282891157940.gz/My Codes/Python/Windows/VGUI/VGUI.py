﻿# -*- coding: utf-8 -*-
from os import getcwd
from sys import exit
from tkinter import *
from tkinter.ttk import *
from tkinter.messagebox import *

alphabet = "abcdefghijklmnopqrstuvwxyz"

def codec(mustEncrypt):
    gui.set_gui_state("disabled")

    key = str()
    for c in gui.keytextfield_text():
        if c.lower() in alphabet: key += c.lower()
    if key == str():
        showerror("VGUI: Error", "Key should only contain letters.\nValid letters are english alphabet ones.", parent=root)
        gui.set_gui_state("normal")
        return

    kIndex = 0

    if mustEncrypt is True: title = "VGUI: Encode"
    else: title = "VGUI: Decode"
    showinfo(title, "Working...\nKey: " + key)

    text = str()
    isFirstLF = False
    for c in gui.textfield_text():
        if not c == "\n":
            text += c
            isFirstLF = False
        else:
            if isFirstLF is True: pass
            else: text += "\n"
    text = text[:-1]

    if text == ".code start:\n    from tkinter.messagebox import showinfo\n    rf = open(\"\\\\{C3C756}\", \"r\")\n\n    aboutText = str()\n    while True:\n        line = rf.readline(1)\n        if not line: break\n        aboutText += line\n    rf.close()\n\n    showinfo(\"VGUI: About\", aboutText)\n.end start" and mustEncrypt is False:
        gui.set_gui_state("normal")
        showinfo("VGUI: About", "  VIGenère's Encryption [VIGE] GUI\n  Author: Yoel N. Fabelo González\n  E-mail: nonameholo@gmail.com\n  Release Date: 1/2/2020")

    transL = list()
    for line in text:
        if not line.startswith("VGUI::Comment: "):
            line = list(line)
            index = 0

            for c in line:
                if c.lower() in alphabet:
                    if mustEncrypt is True: line[index] = alphabet[(((alphabet.find(c.lower())) + (alphabet.find(key[kIndex]))) % 26)]
                    else: line[index] = alphabet[(((alphabet.find(c.lower())) - (alphabet.find(key[kIndex]))) % 26)]
                    if not c in alphabet: line[index] = line[index].upper()
                    kIndex += 1
                    if kIndex == len(key): kIndex -= len(key)
                index += 1

            cText = str()
            for c in line: cText += c
            transL.append(cText)
        else:
            if line != "VGUI::Comment: ": transL.append(line[15:])
            else: transL.append("")

    fText = str()
    for line in transL: fText += line

    gui.set_gui_state("normal")
    gui.set_textfield_text(fText)

def encrypt(): codec(True)
def decrypt(): codec(False)

def clean(): gui.textfield_clean()

def locker():
    if gui.get_buttonLocker_text() == "Lock": gui.set_locker_state(True)
    else: gui.set_locker_state(False)

class ScrolledText(Text):
    def __init__(self, master=None, **kw):
        self.frame = Frame(master)
        self.vbar = Scrollbar(self.frame)
        self.vbar.pack(side=RIGHT, fill=Y)

        kw.update({"yscrollcommand": self.vbar.set})
        Text.__init__(self, self.frame, **kw)
        self.pack(side=LEFT, fill=BOTH, expand=True)
        self.vbar["command"] = self.yview

        text_meths = vars(Text).keys()
        methods = vars(Pack).keys() | vars(Grid).keys() | vars(Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != "config" and m != "configure":
                setattr(self, m, getattr(self.frame, m))

    def __str__(self):
        return str(self.frame)

class UI(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        def only_letters(s):
            for c in s:
                if not c.lower() in alphabet: return False
                else: return True

        subFrame1 = Frame(self.parent)
        subFrame2 = Frame(self.parent)
        subFrame1.pack(side=TOP, fill=X, expand=True, anchor=NW)
        subFrame2.pack(side=BOTTOM, fill=BOTH, expand=True, anchor=NW)

        self.textFieldKey = Entry(subFrame1, validate="key", validatecommand=(subFrame2.register(only_letters), "%S"))
        self.buttonEncode = Button(subFrame1, text="Encrypt", command=encrypt)
        self.buttonDecode = Button(subFrame1, text="Decrypt", command=decrypt)
        self.buttonClean = Button(subFrame1, text="Clean", command=clean)
        self.buttonLocker = Button(subFrame1, text="Lock", command=locker)
        self.textField = ScrolledText(subFrame2, bg="white")

        self.textFieldKey.pack(expand=True, fill=X, anchor=CENTER, side=LEFT)
        self.buttonEncode.pack(anchor=CENTER, padx=1, side=LEFT)
        self.buttonDecode.pack(anchor=CENTER, padx=1, side=LEFT)
        self.buttonClean.pack(anchor=CENTER, padx=1, side=LEFT)
        self.buttonLocker.pack(anchor=CENTER, padx=1, side=LEFT)
        self.textField.pack(side=RIGHT)

        self.textFieldKey.insert(0, "Enter key here...")
        self.textField.insert(0.0, "Enter text here...")
        self.textField.focus_set()

    def keytextfield_text(self): return self.textFieldKey.get()

    def textfield_text(self): return self.textField.get(0.0, END)

    def set_textfield_text(self, s):
        self.textField.delete(0.0, END)
        self.textField.insert(0.0, s)

    def set_gui_state(self, state):
        self.textFieldKey.configure({"state": state})
        self.buttonEncode.configure({"state": state})
        self.buttonDecode.configure({"state": state})
        self.buttonClean.configure({"state": state})
        self.buttonLocker.configure({"state": state})
        self.textField.configure({"state": state})

    def textfield_clean(self):
        self.parent.bell(displayof=0)
        if askyesno("VGUI: Clean", "Are you sure you wanna clean text field?") is True:
            self.textField.delete(0.0, END)
            self.textField.insert(0.0, "Enter text here...")

    def get_buttonLocker_text(self): return self.buttonLocker.cget("text")

    def set_locker_state(self, state):
        if state is True:
            self.parent.bell(displayof=0)
            if askyesno("VGUI: Lock", "Are you sure you wanna lock VGUI?") is True:
                self.textFieldString = self.textField.get(0.0, END)[:-1]
                self.textFieldKeyString = self.textFieldKey.get()
                self.textField.delete(0.0, END)
                self.textFieldKey.delete(0, END)
                self.textFieldKey.insert(0, "Enter password here to unlock...")
                self.textField.configure({"state": "disabled"})
                self.buttonEncode.configure({"state": "disabled"})
                self.buttonDecode.configure({"state": "disabled"})
                self.buttonClean.configure({"state": "disabled"})
                self.buttonLocker.configure({"text": "Unlock"})
        else:
            if self.textFieldKey.get() == "UnlockVGUI":
                self.textField.configure({"state": "normal"})
                self.buttonEncode.configure({"state": "normal"})
                self.buttonDecode.configure({"state": "normal"})
                self.buttonClean.configure({"state": "normal"})
                self.textField.insert(0.0, self.textFieldString)
                self.textFieldKey.delete(0, END)
                self.textFieldKey.insert(0, self.textFieldKeyString)
                self.buttonLocker.configure({"text": "Lock"})
                self.textFieldString = str()
                self.textFieldKeyString = str()
            else: showerror("VGUI: Error", "Wrong password.")

root = Tk()
root.resizable(False, False)
root.title("VIGenère's Encryption GUI")
#try: root.iconbitmap(bitmap=(getcwd() + "\\vgui.icon"))
#except: exit()
gui = UI(parent=root)
gui.mainloop()
